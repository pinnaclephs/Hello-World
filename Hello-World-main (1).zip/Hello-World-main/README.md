# Hello-World

We are Pinnacle Hospitality Solutions, LLC. 

We operate globally.

We are currently registered as a Domestic Limited Liability Company in Delaware, United States of America.

We plan to set out on a destructive path into the entertainment, hospitality, & restaurant industries. 

Food alone accounted for $12T USD in 2019.  

We plan to grow and give back. 

We plan to lift each other up.

We plan to create, every single day.

Welcome to The Pinnacle.

$PIN

#PINcoin

Join our movement today. 



THE CLIMB

PINNACLE HOSPITALITY SOLUTIONS, LLC

Business Objectives

        i.	To create lasting relationships through hospitality experiences and all business conducted with business-to-business partners, our equity stakeholders and our shareholders and charity partners.
        ii.	To create solutions that help small businesses in the hospitality industry through general management consulting and contracted business reviews.
        iii.	To create a blockchain technology platform to invest, share, and operate the various businesses under the Pinnacle Hospitality Solutions umbrella. 
        iv.	To create value, every single day. 
        v.	To follow in the path forge by those entrepreneurs before me and to empower the next generation. 


BUSINESS CASE FOR PINNACLE HOSPITALITY SOLUTIONS, ETC.

    We seek to elevate the hospitality and food service industry. We will do this through our more than thirty-five years of restaurant and corporate food working experience. We plan to treat each transaction with honor and pride in the service we are providing you. We have set goals that align with current industry standards and practices. We plan to give back. 
    In creating solutions to help small business, we are engaging an active and intellectual group of hard-working people just like us. We plan to help them grow their respective businesses while growing our revenue through contracted management services from Pinnacle Hospitality Solutions. At Pinnacle, we are proud of our efforts and look to delegate the in-person work to contractors that have been properly vetted and will grow with Pinnacle. We will continue to employ Search Engine Optimization technology to promote our website and search results on Google, Bing, and any other related search software. We plan to offer Software as a Service to our customers, in that the proprietary business systems reside. This will be where we can create real change in the industry, using algorithmic engineering, we will be quickly and efficiently review and prepare reports for each individual customer. As a cloud-based business we can meet our customers virtually, anywhere, anytime in the world.  We can review all the tangible business data without ever stepping foot into it. During the pandemic, the realization of a global concept became more attainable. Through the massive implementation and adoption of virtual meeting products we can meet more people than we ever could before. Our plan to compile data is a proprietary in-house engineered data system. Based in our home offices in Massachusetts or from our satellite offices in Delaware, we can reach the world. We plan to actively engage our customers, friends, followers, and critics in the social media space. We will actively engage in change because there is no alternative.
    Blockchain technology is so many things. It is an avenue that would have never been in our plan many years ago. With the advent of Bitcoin, Ethereum, and the many altcoins forked off of the major platforms – the crypto market is expected to continue growing. The potential is limitless, following the rule of 7 and the rule of 21, we will create a blockchain by working with an existing token or coin and creating a fork, the PINcoin.  

$PIN 

    Low cost of entry on Ethereum to develop, refine, and launch our token, however the best-case scenario would be proper investment in our own ecosystem and infrastructure. I cannot emphasize the infinite possibilities that creating our own cryptocurrency would open. Please read a short story, “The Pinnacle”, available for reading by request and published on Medium. We will create an interconnected economy of scale for a $3,000,000,000,000 industry. Yes, that is twelve zeroes. Initial smart contract is built to create 100,000,000,000 $PIN. 57 Percent will be liquid, 43 Percent will be locked in a liquidity pool to guarantee the stability of the coin. We are currently in the process of submitting our smart contract for verification and beta testing. We look forward to launch. 
    Our last piece of the puzzle is to create value, every single day. Create new opportunities, new jobs, new technology, new business, new standards, and a new way forward for an industry so deeply underserved by the traditional financial model. An industry where you are often denied service too many times. As entrepreneurs we know that many will say no, they will take a hard pass. Please understand that we set out to change an industry- we hope someday we can impact and improve the lives of so many more. We are achieving our Pinnacle; in turn we shall create one for so many others. Initially, we will donate five percent of our net sales to charity. We plan to be Net-Zero Carbon Emissions and plan to gain recognition and certification for the work we do to improve our world every day. 
    Elon Musk, Jeff Bezos, Tim Apple, Steve Jobs, Vitalik Buterin, Satoshi Nakamoto, and so many others are also for their vision of a better tomorrow through life changing technology – they have inspired this work and I hope to involve any one of them in our future, we will need so much help to get there. 
    
    A special thank you to the team at Alchemy.io for their invaluable assistance.


SUMMARY AND CONCLUSION
  Pinnacle Hospitality Solutions is right now just an idea with great potential. 
  
  Together and with the help of many brilliant minds, this idea has been brainstormed through and through. 
  
  Those involved behind the scenes will forever be part of the reason Pinnacle succeeds. 
  
  We have big dreams, and with big dreams come big risk. 
  
  Big risk should be understood to mean the loss of your potential investment, but with the day-to-day operations of a local catering company with the potential to license, franchise our services and scale – profitability should occur quickly. 
  
  With enough investment for equipment, supplies, and operations expenses, Pinnacle could continue to grow. 


    Initial seed funding round is in progress and the risks involved have been laid out within. This is not financial advice. 

  We are currently seeking up to $10,000,000 in investment for a company valuation of $40,000,000 – a modest value given the industry standards today.


Copyright Pinnacle Hospitality Solutions, LLC, 2021

